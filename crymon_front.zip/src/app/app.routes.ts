import { Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { PlayComponent } from './play/play.component';

export const routes: Routes = [
    {
        path: 'join/:room_code',
        component: HomeComponent
    },
    {
        path: 'play',
        component: PlayComponent
    },
    {
        path: '',
        component: HomeComponent
    }
];
