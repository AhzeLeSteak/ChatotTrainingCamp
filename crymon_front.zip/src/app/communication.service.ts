import { Injectable } from '@angular/core';
import * as signalR from '@microsoft/signalr';
import { BehaviorSubject } from 'rxjs';
import { Room } from '../models/room';


@Injectable({
  providedIn: 'root'
})
export class CommunicationService {
  
  private hub: signalR.HubConnection;

  private _connected = false;
  public readonly roomSubject = new BehaviorSubject<Room>(null!);
  
  constructor() {
    this.hub = new signalR.HubConnectionBuilder()
    .withUrl("http://localhost:5237/room")
    .build();
  }
  
  public async createConnection(){
    await this.hub.start();
    this._connected = true;
    console.log("Connection started");
  }

  private async subscribeUpdate(){
    this.hub.on('UpdateRoom', (room: Room) => {
      console.log(room);
      this.roomSubject.next(room);
    })
  }

  public async createRoom(playerName: string){
    this.hub.invoke('CreateRoom', playerName);
    this.subscribeUpdate();
  }

  public async joinRoom(roomCode: string, playerName: string){
    this.hub.invoke('JoinRoom', roomCode, playerName);
    this.subscribeUpdate();
  }

  public async sendMessage(content: string){
    this.hub.invoke('SendMessage', content);
  }


  public get connected(){
    return this._connected;
  }
  
}
