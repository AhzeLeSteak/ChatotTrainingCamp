import { Component, Input } from '@angular/core';
import { Room } from '../../models/room';

@Component({
  selector: 'app-room-lobby',
  standalone: true,
  imports: [],
  templateUrl: './room-lobby.component.html',
  styleUrl: './room-lobby.component.scss'
})
export class RoomLobbyComponent {

  @Input() room !: Room;

  
}
