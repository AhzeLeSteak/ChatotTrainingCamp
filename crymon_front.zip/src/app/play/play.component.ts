import { Component, OnInit } from '@angular/core';
import { CommunicationService } from '../communication.service';
import { CommonModule } from '@angular/common';
import { InputTextModule } from 'primeng/inputtext';
import { Room } from '../../models/room';

@Component({
  selector: 'app-play',
  standalone: true,
  imports: [CommonModule, InputTextModule],
  templateUrl: './play.component.html',
  styleUrl: './play.component.scss'
})
export class PlayComponent implements OnInit{

  room: Room;
  

  constructor(protected comm: CommunicationService){

  }

  ngOnInit(): void {
    this.comm.roomSubject.subscribe(r => this.room = r);
  }

}
