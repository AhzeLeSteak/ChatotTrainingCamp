import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from "primeng/button";
import { InputTextModule } from 'primeng/inputtext';
import { SelectButtonModule } from 'primeng/selectbutton';
import { CommunicationService } from '../communication.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [SelectButtonModule, FormsModule, InputTextModule, CommonModule, ButtonModule],
  templateUrl: './home.component.html',
  styleUrl: './home.component.scss'
})
export class HomeComponent implements OnInit {

  create_join = [{value: false, label: 'Create a room'}, {value: true, label: 'Join a room'}];
  join = false;
  url_mode = false;

  player_name = '';
  room_code = '';

  constructor(private comm: CommunicationService,
              private route: ActivatedRoute,
              private router: Router
  ){

  }

  ngOnInit(): void {
    this.route.paramMap.subscribe(params => {
      this.room_code = params.get('room_code') ?? '';
      if(this.room_code){
        this.join = true;
        this.url_mode = true;
      }
    })
  }

  async letsgo(){
    await this.comm.createConnection();
    if(this.join)
      this.comm.joinRoom(this.room_code, this.player_name);
    else
      this.comm.createRoom(this.player_name);
    this.comm.roomSubject.subscribe(room => {
      if(room)
        this.router.navigate(['play']);
    });
  }
  
}
