export interface RoomParams{
    nbRounds: number;
    generation: number[];
}