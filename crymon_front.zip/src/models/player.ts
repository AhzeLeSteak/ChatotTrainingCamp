export class Player{
    name: string;
    connected: boolean;
}