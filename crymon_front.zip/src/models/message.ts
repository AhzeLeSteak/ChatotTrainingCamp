export interface Message{
    playerName: string;
    content: string;
}