import { Message } from "./message";
import { Player } from "./player";
import { RoomParams } from "./room-params";

export interface Room {
    code: string;
    status: RoomStatus;
    players: Player[];
    messages: Message[];
    params: RoomParams;
}

export enum RoomStatus{
    Waiting,
    Playing,
}